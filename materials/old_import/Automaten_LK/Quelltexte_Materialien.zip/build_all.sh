#!/usr/bin/env bash
# Baut alle Materialien neu. Mit QR-Codes:  AUTOMATENLAB_URL="https://automatenlab.deine-domain.de/" ./build_all.sh
set -e
cd "$(dirname "$0")/content"
for d in ds01 ds02 ds03 ds04 ds05 ds06 ds07 ds08 ds09 ds10 ds11 ds12 ds13 ds14 ds15 ds16 abschluss planung; do
  [ -d "$d" ] || continue
  echo "== $d"
  ( cd "$d"
    for f in automata_*.py; do [ -e "$f" ] && python3 "$f" > /dev/null; done
    for f in build_*.js; do [ -e "$f" ] && node "$f" > /dev/null; done )
done
echo "fertig – Ausgaben in $(cd .. && pwd)/out"
