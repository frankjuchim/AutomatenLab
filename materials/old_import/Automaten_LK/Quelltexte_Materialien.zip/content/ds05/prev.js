// Vorschau: node prev.js <datei.docx|pptx> ... → PNG/JPG in build/prev + Kontaktbogen
const D = require('/home/claude/unit/lib/docstyle.js');
const S = require('/home/claude/unit/lib/deckstyle.js');
const path = require('path');
const PREV = '/home/claude/unit/build/prev';
for (const f of process.argv.slice(2)) {
  const base = path.basename(f).replace(/\.(docx|pptx)$/, '');
  for (const old of require('fs').readdirSync(PREV)) if (old.startsWith(base)) require('fs').unlinkSync(path.join(PREV, old));
  if (f.endsWith('.pptx')) {
    const imgs = S.preview(f, PREV);
    S.contactSheet(imgs, `${PREV}/${base}_sheet.jpg`, 4);
    console.log(base, imgs.length, 'Folien');
  } else {
    const imgs = D.preview(f, PREV);
    S.contactSheet(imgs, `${PREV}/${base}_sheet.png`, Math.min(imgs.length, 4));
    console.log(base, imgs.length, 'Seiten');
  }
}
